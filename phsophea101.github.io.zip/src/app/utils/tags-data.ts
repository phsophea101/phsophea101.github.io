export const tagData = [
  { displayName: 'Angular', isSelected: true },
  { displayName: 'React.js', isSelected: true },
  { displayName: 'Node.js', isSelected: true },
  { displayName: 'ASP.NET', isSelected: true },
  { displayName: 'CSS', isSelected: true },
  { displayName: 'Others', isSelected: !true }
];
