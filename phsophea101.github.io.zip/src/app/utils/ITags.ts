export interface ITag {
  displayName: string;
  isSelected: boolean;
}
