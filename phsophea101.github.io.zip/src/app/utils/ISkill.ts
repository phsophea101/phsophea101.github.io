export interface ISkill {
  type: string;
  names: string[];
}
